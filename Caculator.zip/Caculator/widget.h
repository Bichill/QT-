#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QStack>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_btn1_clicked();

    void on_btn2_clicked();

    void on_btn3_clicked();

    void on_btn4_clicked();

    void on_btn5_clicked();

    void on_btn6_clicked();

    void on_btn7_clicked();

    void on_btn8_clicked();

    void on_btn9_clicked();

    void on_btn0_clicked();

    void on_btnAdd_clicked();

    void on_btnSubtract_clicked();

    void on_btnMultiply_clicked();

    void on_btnExcept_clicked();

    void on_btnEquel_clicked();

    void on_btnLeftBracket_clicked();

    void on_btnRightBracket_clicked();

    void on_btnClear_clicked();

    void on_btnDelet_clicked();

    int Priority(char ch);

private:
    Ui::Widget *ui;
    QString expression;
};
#endif // WIDGET_H
