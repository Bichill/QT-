#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    this->setMaximumSize(258,407);
    this->setMinimumSize(258,407);
    this->setWindowTitle("计算器");

    QFont f("圆体",16);//字体对象
    ui->mainLineEdit->setFont(f);

    ///改变按钮背景色
    ui->btnEquel->setStyleSheet("background:orange");
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_btn1_clicked()
{
    expression+="1";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn2_clicked()
{
    expression+="2";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn3_clicked()
{
    expression+="3";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn4_clicked()
{
    expression+="4";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn5_clicked()
{
    expression+="5";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn6_clicked()
{
    expression+="6";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn7_clicked()
{
    expression+="7";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn8_clicked()
{
    expression+="8";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn9_clicked()
{
    expression+="9";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btn0_clicked()
{
    expression+="0";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btnAdd_clicked()
{
    expression+="+";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btnSubtract_clicked()
{
    expression+="-";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btnMultiply_clicked()
{
    expression+="*";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btnExcept_clicked()
{
    expression+="/";
    ui->mainLineEdit->setText(expression);
}



void Widget::on_btnLeftBracket_clicked()
{
    expression+="(";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btnRightBracket_clicked()
{
    expression+=")";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_btnClear_clicked()
{
    expression.clear();
    ui->mainLineEdit->clear();
}


void Widget::on_btnDelet_clicked()
{
    expression.chop(1);
    ui->mainLineEdit->setText(expression);
}

void Widget::on_btnEquel_clicked()
{
    QStack<int> s_num,s_opt;

    char opt[128] = {0};
    int i=0,tmp=0,num1,num2;

    //QString转换成*char
    QByteArray ba = expression.toLatin1();
    strcpy(opt,ba.data()); ///data把QBtyeArray转换为const char*

    while(opt[i]!='\0' || s_opt.empty()!=true)
    {
        if(opt[i]>='0' && opt[i]<='9')
        {
            tmp = tmp*10 + opt[i]-'0';
            i++;
            if(opt[i]<'0'||opt[i]>'9')
            {
                s_num.push(tmp);
                tmp=0;
            }
        }
        else
        {
            if(s_opt.empty()==true||Priority(opt[i])>Priority(s_opt.top())||(s_opt.top()=='('&&opt[i]!=')'))
            {
                s_opt.push(opt[i]);
                i++;
                continue;
            }

            if(s_opt.top()=='('&&opt[i]==')')
            {
                //就是如果出现1+()+2这种空括号的情况
                s_opt.pop();
                i++;
                continue;
            }

            if(Priority(opt[i])<=Priority(s_opt.top())||(opt[i]==')'&&s_opt.top()!='(')||
                (opt[i]=='\0'&&s_opt.empty()!=true))
            {
                char ch = s_opt.top();
                s_opt.pop();
                switch(ch)
                {
                case '+':
                    num1 = s_num.top();
                    s_num.pop();
                    num2 = s_num.top();
                    s_num.pop();
                    s_num.push(num1+num2);
                    break;
                case '-':
                    num1 = s_num.top();
                    s_num.pop();
                    num2 = s_num.top();
                    s_num.pop();
                    s_num.push(num1-num2);
                    break;
                case '*':
                    num1 = s_num.top();
                    s_num.pop();
                    num2 = s_num.top();
                    s_num.pop();
                    s_num.push(num1*num2);
                    break;
                case '/':
                    num1 = s_num.top();
                    s_num.pop();
                    num2 = s_num.top();
                    s_num.pop();
                    s_num.push(num1/num2);
                    break;
                }
            }
        }
    }
    ui->mainLineEdit->setText(QString::number(s_num.top()));
    expression.clear();
}

int Widget::Priority(char ch)
{
    int res;
    switch(ch)
    {
        case'(':
            res = 3;
            break;
        case'*':
        case'/':
            res = 2;
            break;
        case'+':
        case'-':
            res = 1;
            break;
        default:
            res = 0;
            break;
    }
        return res;

}
